﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RockPaperScissors
{
    public partial class Form1 : Form
    {
        Random rnd = new Random();
        int i;
        string message = null;
        string title = "Result";
        int playerWin =0;
        int cpuWin = 0;
        public Form1()
        {
            InitializeComponent();
            rockpb.Visible = false;
            scissorspb.Visible = false;
            paperpb.Visible = false;
            rockpbcpu.Visible = false;
            scissorspbcpu.Visible = false;
            paperpbcpu.Visible = false;
           

        }


        private void rockpb_Click(object sender, EventArgs e)
        {

        }


        private void qqpb_Click(object sender, EventArgs e)
        {

        }

        private void paperpb_Click(object sender, EventArgs e)
        {

        }

        private void scissorspb_Click(object sender, EventArgs e)
        {

        }

        private void scissorspbcpu_Click(object sender, EventArgs e)
        {

        }

        private void rockpbcpu_Click(object sender, EventArgs e)
        {

        }

        private void paperpbcpu_Click(object sender, EventArgs e)
        {

        }

        private void qqpbcpu_Click(object sender, EventArgs e)
        {

        }

        private void playAgain_Click(object sender, EventArgs e)
        {
            rockpb.Visible = false;
            scissorspb.Visible = false;
            paperpb.Visible = false;
            rockpbcpu.Visible = false;
            scissorspbcpu.Visible = false;
            paperpbcpu.Visible = false;
            qqpb.Visible = true;
            qqpbcpu.Visible = true;
        }

        private void reset_Click(object sender, EventArgs e)
        {
            playerWin = 0;
            cpuWin = 0;
            playercount.Text = null;
            cpucount.Text = null;
            rockpb.Visible = false;
            scissorspb.Visible = false;
            paperpb.Visible = false;
            rockpbcpu.Visible = false;
            scissorspbcpu.Visible = false;
            paperpbcpu.Visible = false;
            qqpb.Visible = true;
            qqpbcpu.Visible = true;
            playercount.BackColor = Color.White;
            cpucount.BackColor = Color.White;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
        }

        private void Rock_Click(object sender, EventArgs e)
        {
            rockpb.Visible = true;
            scissorspb.Visible = false;
            paperpb.Visible = false;
            rockpbcpu.Visible = false;
            scissorspbcpu.Visible = false;
            paperpbcpu.Visible = false;
            qqpb.Visible = false;
            i = rnd.Next(1, 3);
            if (i==1)
            {
                rockpbcpu.Visible = true;
                message = "Draw!";
                MessageBox.Show(message, title);
                playercount.Text = playerWin.ToString();
                cpucount.Text = cpuWin.ToString();
            }
            else if (i == 2)
            {
                paperpbcpu.Visible = true;
                message = "CPU wins!s";
                MessageBox.Show(message, title);
                cpuWin++;
                playercount.Text = playerWin.ToString();
                cpucount.Text = cpuWin.ToString();
            }
            else if (i == 3)
            {
                scissorspbcpu.Visible = true;
                message = "Player Wins";
                MessageBox.Show(message, title);
                playerWin++;
                playercount.Text = playerWin.ToString();
                cpucount.Text = cpuWin.ToString();
            }
            if (playerWin > cpuWin)
            {
                playercount.BackColor = Color.Green;
                cpucount.BackColor = Color.Red;
            }
            if (playerWin < cpuWin)
            {
                playercount.BackColor = Color.Red;
                cpucount.BackColor = Color.Green;
            }
            if (playerWin == cpuWin)
            {
                playercount.BackColor = Color.Yellow;
                cpucount.BackColor = Color.Yellow;
            }

        }
        
        private void Paper_Click(object sender, EventArgs e)
        {
            rockpb.Visible = false;
            scissorspb.Visible = false;
            paperpb.Visible = true;
            rockpbcpu.Visible = false;
            scissorspb.Visible = true;
            scissorspbcpu.Visible = false;
            paperpbcpu.Visible = false;
            qqpb.Visible = false;
            i = rnd.Next(1, 3);
            if (i == 1)
            {
                rockpbcpu.Visible = true;
                message = "Player Wins";
                MessageBox.Show(message, title);
                playerWin++;
                playercount.Text = playerWin.ToString();
                cpucount.Text = cpuWin.ToString();
            }
            else if (i == 2)
            {
                paperpbcpu.Visible = true;
                message = "Draw!";
                MessageBox.Show(message, title);
                playercount.Text = playerWin.ToString();
                cpucount.Text = cpuWin.ToString();

            }
            else if (i == 3)
            {
                scissorspbcpu.Visible = true;
                message = "CPU wins!";
                MessageBox.Show(message, title);
                cpuWin++;
                playercount.Text = playerWin.ToString();
                cpucount.Text = cpuWin.ToString();

            }
            if (playerWin > cpuWin)
            {
                playercount.BackColor = Color.Green;
                cpucount.BackColor = Color.Red;
            }
            if (playerWin < cpuWin)
            {
                playercount.BackColor = Color.Red;
                cpucount.BackColor = Color.Green;
            }
            if (playerWin == cpuWin)
            {
                playercount.BackColor = Color.Yellow;
                cpucount.BackColor = Color.Yellow;
            }
        }

        private void Scissors_Click(object sender, EventArgs e)
        {
            rockpb.Visible = false;
            paperpb.Visible = false;
            rockpbcpu.Visible = false;
            scissorspb.Visible = true;
            scissorspbcpu.Visible = false;
            paperpbcpu.Visible = false;
            qqpb.Visible = false;
            i = rnd.Next(1, 3);
            if (i == 1)
            {
                rockpbcpu.Visible = true;
                message = "CPU wins!";
                MessageBox.Show(message, title);
                cpuWin++;
                playercount.Text = playerWin.ToString();
                cpucount.Text = cpuWin.ToString();
            }
            else if (i == 2)
            {
                paperpbcpu.Visible = true;
                message = "Player Wins";
                MessageBox.Show(message, title);
                playerWin++;
                playercount.Text = playerWin.ToString();
                cpucount.Text = cpuWin.ToString();
            }
            else if (i == 3)
            {
                scissorspbcpu.Visible = true;
                message = "Draw!";
                MessageBox.Show(message, title);
                playercount.Text = playerWin.ToString();
                cpucount.Text = cpuWin.ToString();

            }
            if (playerWin > cpuWin)
            { playercount.BackColor = Color.Green;
                cpucount.BackColor = Color.Red;
            }
            if (playerWin < cpuWin)
            {
                playercount.BackColor = Color.Red;
                cpucount.BackColor = Color.Green; }
            if (playerWin == cpuWin)
            {
                playercount.BackColor = Color.Yellow;
                cpucount.BackColor = Color.Yellow; 
            }
        }

        private void playercount_Click(object sender, EventArgs e)
        {
            
        }

        private void cpucount_Click(object sender, EventArgs e)
        {

        }
    }
}

﻿
namespace RockPaperScissors
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.qqpb = new System.Windows.Forms.PictureBox();
            this.qqpbcpu = new System.Windows.Forms.PictureBox();
            this.Rock = new System.Windows.Forms.Button();
            this.Paper = new System.Windows.Forms.Button();
            this.Scissors = new System.Windows.Forms.Button();
            this.reset = new System.Windows.Forms.Button();
            this.playAgain = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.paperpb = new System.Windows.Forms.PictureBox();
            this.paperpbcpu = new System.Windows.Forms.PictureBox();
            this.rockpb = new System.Windows.Forms.PictureBox();
            this.rockpbcpu = new System.Windows.Forms.PictureBox();
            this.scissorspb = new System.Windows.Forms.PictureBox();
            this.scissorspbcpu = new System.Windows.Forms.PictureBox();
            this.playercount = new System.Windows.Forms.Button();
            this.cpucount = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.qqpb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.qqpbcpu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.paperpb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.paperpbcpu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rockpb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rockpbcpu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.scissorspb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.scissorspbcpu)).BeginInit();
            this.SuspendLayout();
            // 
            // qqpb
            // 
            this.qqpb.Image = ((System.Drawing.Image)(resources.GetObject("qqpb.Image")));
            this.qqpb.Location = new System.Drawing.Point(186, 145);
            this.qqpb.Name = "qqpb";
            this.qqpb.Size = new System.Drawing.Size(278, 247);
            this.qqpb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.qqpb.TabIndex = 0;
            this.qqpb.TabStop = false;
            this.qqpb.Click += new System.EventHandler(this.qqpb_Click);
            // 
            // qqpbcpu
            // 
            this.qqpbcpu.Image = ((System.Drawing.Image)(resources.GetObject("qqpbcpu.Image")));
            this.qqpbcpu.Location = new System.Drawing.Point(713, 145);
            this.qqpbcpu.Name = "qqpbcpu";
            this.qqpbcpu.Size = new System.Drawing.Size(278, 247);
            this.qqpbcpu.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.qqpbcpu.TabIndex = 1;
            this.qqpbcpu.TabStop = false;
            this.qqpbcpu.Click += new System.EventHandler(this.qqpbcpu_Click);
            // 
            // Rock
            // 
            this.Rock.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Rock.Location = new System.Drawing.Point(31, 145);
            this.Rock.Name = "Rock";
            this.Rock.Size = new System.Drawing.Size(106, 68);
            this.Rock.TabIndex = 2;
            this.Rock.Text = "Rock";
            this.Rock.UseVisualStyleBackColor = true;
            this.Rock.Click += new System.EventHandler(this.Rock_Click);
            // 
            // Paper
            // 
            this.Paper.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Paper.Location = new System.Drawing.Point(31, 233);
            this.Paper.Name = "Paper";
            this.Paper.Size = new System.Drawing.Size(106, 68);
            this.Paper.TabIndex = 3;
            this.Paper.Text = "Paper";
            this.Paper.UseVisualStyleBackColor = true;
            this.Paper.Click += new System.EventHandler(this.Paper_Click);
            // 
            // Scissors
            // 
            this.Scissors.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Scissors.Location = new System.Drawing.Point(31, 324);
            this.Scissors.Name = "Scissors";
            this.Scissors.Size = new System.Drawing.Size(106, 68);
            this.Scissors.TabIndex = 4;
            this.Scissors.Text = "Scissors";
            this.Scissors.UseVisualStyleBackColor = true;
            this.Scissors.Click += new System.EventHandler(this.Scissors_Click);
            // 
            // reset
            // 
            this.reset.BackColor = System.Drawing.Color.Red;
            this.reset.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.reset.Location = new System.Drawing.Point(589, 480);
            this.reset.Name = "reset";
            this.reset.Size = new System.Drawing.Size(156, 74);
            this.reset.TabIndex = 5;
            this.reset.Text = "Reset Game";
            this.reset.UseVisualStyleBackColor = false;
            this.reset.Click += new System.EventHandler(this.reset_Click);
            // 
            // playAgain
            // 
            this.playAgain.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.playAgain.Location = new System.Drawing.Point(424, 480);
            this.playAgain.Name = "playAgain";
            this.playAgain.Size = new System.Drawing.Size(159, 74);
            this.playAgain.TabIndex = 6;
            this.playAgain.Text = "Play Again";
            this.playAgain.UseVisualStyleBackColor = true;
            this.playAgain.Click += new System.EventHandler(this.playAgain_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(713, 93);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(278, 43);
            this.button1.TabIndex = 7;
            this.button1.Text = "CPU";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(186, 93);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(278, 43);
            this.button2.TabIndex = 8;
            this.button2.Text = "Player";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.DodgerBlue;
            this.button3.Font = new System.Drawing.Font("Lucida Calligraphy", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(530, 233);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(127, 95);
            this.button3.TabIndex = 9;
            this.button3.Text = "VS";
            this.button3.UseVisualStyleBackColor = false;
            // 
            // paperpb
            // 
            this.paperpb.Image = ((System.Drawing.Image)(resources.GetObject("paperpb.Image")));
            this.paperpb.Location = new System.Drawing.Point(186, 145);
            this.paperpb.Name = "paperpb";
            this.paperpb.Size = new System.Drawing.Size(278, 247);
            this.paperpb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.paperpb.TabIndex = 10;
            this.paperpb.TabStop = false;
            this.paperpb.Click += new System.EventHandler(this.paperpb_Click);
            // 
            // paperpbcpu
            // 
            this.paperpbcpu.Image = ((System.Drawing.Image)(resources.GetObject("paperpbcpu.Image")));
            this.paperpbcpu.Location = new System.Drawing.Point(713, 145);
            this.paperpbcpu.Name = "paperpbcpu";
            this.paperpbcpu.Size = new System.Drawing.Size(278, 247);
            this.paperpbcpu.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.paperpbcpu.TabIndex = 11;
            this.paperpbcpu.TabStop = false;
            this.paperpbcpu.Click += new System.EventHandler(this.paperpbcpu_Click);
            // 
            // rockpb
            // 
            this.rockpb.Image = ((System.Drawing.Image)(resources.GetObject("rockpb.Image")));
            this.rockpb.Location = new System.Drawing.Point(186, 145);
            this.rockpb.Name = "rockpb";
            this.rockpb.Size = new System.Drawing.Size(278, 247);
            this.rockpb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.rockpb.TabIndex = 12;
            this.rockpb.TabStop = false;
            this.rockpb.Click += new System.EventHandler(this.rockpb_Click);
            // 
            // rockpbcpu
            // 
            this.rockpbcpu.Image = ((System.Drawing.Image)(resources.GetObject("rockpbcpu.Image")));
            this.rockpbcpu.Location = new System.Drawing.Point(713, 145);
            this.rockpbcpu.Name = "rockpbcpu";
            this.rockpbcpu.Size = new System.Drawing.Size(278, 247);
            this.rockpbcpu.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.rockpbcpu.TabIndex = 13;
            this.rockpbcpu.TabStop = false;
            this.rockpbcpu.Click += new System.EventHandler(this.rockpbcpu_Click);
            // 
            // scissorspb
            // 
            this.scissorspb.Image = ((System.Drawing.Image)(resources.GetObject("scissorspb.Image")));
            this.scissorspb.Location = new System.Drawing.Point(186, 145);
            this.scissorspb.Name = "scissorspb";
            this.scissorspb.Size = new System.Drawing.Size(278, 247);
            this.scissorspb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.scissorspb.TabIndex = 14;
            this.scissorspb.TabStop = false;
            this.scissorspb.Click += new System.EventHandler(this.scissorspb_Click);
            // 
            // scissorspbcpu
            // 
            this.scissorspbcpu.Image = ((System.Drawing.Image)(resources.GetObject("scissorspbcpu.Image")));
            this.scissorspbcpu.Location = new System.Drawing.Point(713, 145);
            this.scissorspbcpu.Name = "scissorspbcpu";
            this.scissorspbcpu.Size = new System.Drawing.Size(278, 247);
            this.scissorspbcpu.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.scissorspbcpu.TabIndex = 15;
            this.scissorspbcpu.TabStop = false;
            this.scissorspbcpu.Click += new System.EventHandler(this.scissorspbcpu_Click);
            // 
            // playercount
            // 
            this.playercount.BackColor = System.Drawing.Color.White;
            this.playercount.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.playercount.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.playercount.Location = new System.Drawing.Point(470, 93);
            this.playercount.Name = "playercount";
            this.playercount.Size = new System.Drawing.Size(90, 62);
            this.playercount.TabIndex = 16;
            this.playercount.UseVisualStyleBackColor = false;
            this.playercount.Click += new System.EventHandler(this.playercount_Click);
            // 
            // cpucount
            // 
            this.cpucount.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.cpucount.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.cpucount.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cpucount.Location = new System.Drawing.Point(617, 93);
            this.cpucount.Name = "cpucount";
            this.cpucount.Size = new System.Drawing.Size(90, 62);
            this.cpucount.TabIndex = 17;
            this.cpucount.UseVisualStyleBackColor = false;
            this.cpucount.Click += new System.EventHandler(this.cpucount_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.ClientSize = new System.Drawing.Size(1057, 636);
            this.Controls.Add(this.cpucount);
            this.Controls.Add(this.playercount);
            this.Controls.Add(this.scissorspbcpu);
            this.Controls.Add(this.scissorspb);
            this.Controls.Add(this.rockpbcpu);
            this.Controls.Add(this.rockpb);
            this.Controls.Add(this.paperpbcpu);
            this.Controls.Add(this.paperpb);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.playAgain);
            this.Controls.Add(this.reset);
            this.Controls.Add(this.Scissors);
            this.Controls.Add(this.Paper);
            this.Controls.Add(this.Rock);
            this.Controls.Add(this.qqpbcpu);
            this.Controls.Add(this.qqpb);
            this.Name = "Form1";
            this.Text = "Rock Paper Scissors";
            ((System.ComponentModel.ISupportInitialize)(this.qqpb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.qqpbcpu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.paperpb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.paperpbcpu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rockpb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rockpbcpu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.scissorspb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.scissorspbcpu)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox qqpb;
        private System.Windows.Forms.PictureBox qqpbcpu;
        private System.Windows.Forms.Button Rock;
        private System.Windows.Forms.Button Paper;
        private System.Windows.Forms.Button Scissors;
        private System.Windows.Forms.Button reset;
        private System.Windows.Forms.Button playAgain;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.PictureBox paperpb;
        private System.Windows.Forms.PictureBox paperpbcpu;
        private System.Windows.Forms.PictureBox rockpb;
        private System.Windows.Forms.PictureBox rockpbcpu;
        private System.Windows.Forms.PictureBox scissorspb;
        private System.Windows.Forms.PictureBox scissorspbcpu;
        private System.Windows.Forms.Button playercount;
        private System.Windows.Forms.Button cpucount;
    }
}

